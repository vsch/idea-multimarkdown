1. test

    ```php
        'Form'      => Collective\Html\FormFacade::class,
        'Html'      => Collective\Html\HtmlFacade::class,
        'Html'      => Collective\Html\HtmlFacade::class,
    ```
           'Form'      => Collective\Html\FormFacade::class,
             'Html'      => Collective\Html\HtmlFacade::class,
               'Html'      => Collective\Html\HtmlFacade::class,

![d](images/ScreenShot_html.png) 

![ref image] 

[Completions](completions.md) 

[Completions] 

[ref image]: images/ScreenShot_html%402x.png
[Completions]: completions.md
