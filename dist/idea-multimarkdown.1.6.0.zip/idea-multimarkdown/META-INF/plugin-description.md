![Screenshot](https://raw.githubusercontent.com/vsch/idea-multimarkdown/master/assets/images/plugin_description_img.png)

### Markdown Navigator

[<span style="color:#30A0D8">Markdown</span>](http://daringfireball.net/projects/markdown)
language support for IntelliJ platform, with GitHub Flavoured Markdown extensions, GitHub style
formatting and HTML Preview.

**The Markdown plugin for more than just previewing. Features include link address
completions, refactoring, validation and language injections. Works with GitHub wiki and main
repository files.**

**<span style="color:#b200c2">Split Editor</span>** and **HTML text** preview in
**[<span style="color:#30A0D8">Enhanced Edition</span>](http://vladsch.com/product/markdown-navigator)**

**Plugin website:
[<span style="color:#30A0D8">Markdown Navigator Enhanced Edition</span>](http://vladsch.com/product/markdown-navigator)**

**Bug tracking & feature requests:
[<span style="color:#30A0D8">GitHub Issues</span>](https://github.com/vsch/idea-multimarkdown/issues)**

**Documentation:
[<span style="color:#30A0D8">GitHub Wiki pages.</span>](https://github.com/vsch/idea-multimarkdown/wiki)**
