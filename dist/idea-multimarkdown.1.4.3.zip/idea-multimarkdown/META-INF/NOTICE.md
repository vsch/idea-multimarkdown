NOTICE   
------

This product is based on or uses the following copyrighted materials released under their respective licenses. 

*   based on open source idea-multimarkdown - markdown plugin for IntelliJ products  
    Copyright 2015 Vladimir Schneider <https://github.com/vsch/idea-multimarkdown>  
    <http://www.apache.org/licenses/LICENSE-2.0>  
      
    *   based on idea-markdown - markdown plugin for IntelliJ products  
        Copyright 2011-2014 Julien Nicoulaud <https://github.com/nicoulaj/idea-markdown>  
        <http://www.apache.org/licenses/LICENSE-2.0>  
  
    *   This software includes code from IntelliJ IDEA Community Edition  
        Copyright (C) JetBrains s.r.o.  
        https://www.jetbrains.com/idea/  
          
    *   parts based on code from IntelliJ IDEA open source Plugins  
        Copyright (C) JetBrains s.r.o.  
        https://github.com/vsch/intellij-plugins  
          
    *   includes highlight.js   
        Copyright (c) 2006, Ivan Sagalaev, <https://github.com/isagalaev/highlight.js>  
        <https://github.com/isagalaev/highlight.js/blob/master/LICENSE>                 
          
    *   includes asm-all-4.1.jar  
        Copyright (c) 2012 France Télécom, All rights reserved.  
        <http://asm.ow2.org/asmdex-license.html>    
        
    *   parts based on https://github.com/sindresorhus/github-markdown-css  
        Copyright (c) 2014-2015 Sindre Sorhus <http://sindresorhus.com>  
        <https://opensource.org/licenses/MIT>                 
  
    *   parts based on gfm-plugin  
        Copyright (c) 2015 shyyko.serhiy <https://github.com/ShyykoSerhiy/gfm-plugin>  
        <https://opensource.org/licenses/MIT>                 
  
    *   parts based on intellij-plugin-copy-and-open-github-url  
        Copyright 2013 Square, Inc. <https://github.com/jawspeak/intellij-plugin-copy-and-open-github-url>  
        No license information provided                 
  
    *   parts based on LanguageTextField  
        Copyright 2006 Sascha Weinreuter  
        <http://www.apache.org/licenses/LICENSE-2.0>  
  
    *   includes Apache Commons IO software developed by  
        Copyright 2002-2012 The Apache Software Foundation  
        The Apache Software Foundation (http://www.apache.org/).  
        <http://www.apache.org/licenses/LICENSE-2.0>  
      
    *   includes Apache Commons Validator software developed by  
        Copyright 2001-2014 The Apache Software Foundation  
        The Apache Software Foundation (http://www.apache.org/).  
        <http://www.apache.org/licenses/LICENSE-2.0>  
      
*   includes pegdown - A pure-Java Markdown processor based on a parboiled PEG parser supporting a number of extensions  
    Copyright (C) 2010-2015 Mathias Doenitz (http://pegdown.org)  
    <http://www.apache.org/licenses/LICENSE-2.0>  
      
    *   based on peg-markdown - markdown in c, implemented using PEG grammar  
        Copyright (c) 2008 John MacFarlane (http://github.com/jgm/peg-markdown)  
